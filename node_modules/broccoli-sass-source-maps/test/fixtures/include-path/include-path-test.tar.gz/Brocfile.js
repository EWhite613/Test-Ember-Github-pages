var sass = require('broccoli-sass');

var sourceTrees = ['assets'];
sourceTrees = sourceTrees.concat(require('node-neat').includePaths);
module.exports = sass(sourceTrees, 'test.scss', 'test.css');
